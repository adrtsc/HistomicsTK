"""This package contains methods to parse annotations to masks and vice versa.

It also contains various utilities to deal with polygons and algorithmic
segmentation results.

"""
