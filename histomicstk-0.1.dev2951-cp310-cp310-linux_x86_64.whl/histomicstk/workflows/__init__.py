"""Module to run specific workflows on groups of slides.

Note that this is separate from the server-side way of doing things.
This is just a convenience utility for developers and machine learning
engineers who would like to run the same function over all slides
in a girder directory.

"""
