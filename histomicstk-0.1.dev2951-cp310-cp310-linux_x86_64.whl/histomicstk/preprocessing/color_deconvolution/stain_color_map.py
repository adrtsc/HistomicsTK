# Please see __init__.py in this folder for documentation
stain_color_map = {
    'hematoxylin': [0.65, 0.70, 0.29],
    'eosin': [0.07, 0.99, 0.11],
    'dab': [0.27, 0.57, 0.78],
    'null': [0.0, 0.0, 0.0],
}
