=======
Credits
=======

Contributors
------------

* Mohamed Amgad <mtageld@emory.edu>
* Jonathan Beezeley <jonathan.beezeley@kitware.com>
* Deepak Roy Chittajallu <deepak.chittajallu@kitware.com>
* Lee Cooper <lee.cooper@emory.edu>
* David Gutman <david.gutman@kitware.com>
* Brian Helba <brian.helba@kitware.com>
* Sanghoon Lee <sanghoon.lee@emory.edu>
* David Manthey <david.manthey@kitware.com>
* Zach Mullen <zach.mullen@kitware.com>

* You! Why not contribute?
